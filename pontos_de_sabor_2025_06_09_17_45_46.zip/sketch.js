// Jogo: Pontes de Sabor - Do Campo à Cidade v2.0
// Tema: Festejando conexão campo-cidade (Concurso Agrinho 2025 Paraná)

let gameState = "MENU"; // MENU, PLAYING, INSTRUCTIONS, GAMEOVER, VICTORY
let score = 0;
let level = 1;
let timer = 60;

// Produtos e mercados
let products = ["milho", "tomate", "leite", "ovos", "alface"];
let routes = [];
let farms = [];
let markets = [];
let festivalsCompleted = 0;
let activeConnections = [];
let draggedItem = null;
let trucks = []; // Array para os caminhões

// Cores
let colorField = "#7CBA01";
let colorCity = "#436B95";
let colorRoute = "#F2A71B";
let colorUI = "#F25749";

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
  setupLevel(level);
}

function setupLevel(lvl) {
  farms = [];
  markets = [];
  routes = [];
  activeConnections = [];
  trucks = [];
  
  // Criar fazendas (lado esquerdo - campo)
  for (let i = 0; i < lvl + 2; i++) {
    farms.push({
      x: 100,
      y: 150 + i * 80,
      product: products[i % products.length],
      connected: false,
      size: 50
    });
  }
  
  // Criar mercados (lado direito - cidade)
  for (let i = 0; i < lvl + 1; i++) {
    markets.push({
      x: 700,
      y: 180 + i * 90,
      needsProduct: products[(i + 1) % products.length],
      connected: false,
      size: 60
    });
  }
  
  timer = 60 + (lvl * 10);
}

function draw() {
  background(240);
  
  switch (gameState) {
    case "MENU":
      drawMenu();
      break;
    case "INSTRUCTIONS":
      drawInstructions();
      break;
    case "PLAYING":
      drawGame();
      updateGame();
      break;
    case "GAMEOVER":
      drawGameOver();
      break;
    case "VICTORY":
      drawVictory();
      break;
  }
}

function drawMenu() {
  background(colorField);
  
  // Título com estilo
  fill(255);
  stroke(0);
  strokeWeight(3);
  textSize(48);
  text("🌾 Pontes de Sabor 🏙️", width/2, 120);
  textSize(24);
  noStroke();
  text("Do Campo à Cidade", width/2, 180);
  
  // Decoração
  drawFarmIcon(150, 220);
  drawCityIcon(650, 220);
  drawTruck(400, 220, 0);
  
  // Botões
  drawButton(width/2, 320, 200, 60, "JOGAR", colorRoute);
  drawButton(width/2, 400, 200, 60, "INSTRUÇÕES", colorCity);
  
  // Créditos
  fill(255);
  textSize(16);
  text("Concurso Agrinho 2025 - Paraná", width/2, height - 40);
}

function drawInstructions() {
  background(colorCity);
  
  fill(255);
  textSize(36);
  text("Como Jogar", width/2, 80);
  
  textSize(18);
  textAlign(LEFT);
  text("🚜 1. Conecte as fazendas com os mercados da cidade", 50, 160);
  text("🎯 2. Arraste do produto para o mercado que precisa dele", 50, 200);
  text("📦 3. Veja os caminhões transportarem os produtos!", 50, 240);
  text("⏰ 4. Complete todos os mercados antes que o tempo acabe", 50, 280);
  text("📈 5. Cada nível adiciona mais fazendas e mercados", 50, 320);
  textAlign(CENTER);
  
  // Botão voltar
  drawButton(width/2, 450, 200, 60, "VOLTAR", colorRoute);
}

function drawGame() {
  // Desenhar fundo dividido (campo e cidade)
  noStroke();
  fill(colorField);
  rect(0, 0, width/2, height);
  fill(colorCity);
  rect(width/2, 0, width/2, height);
  
  // Linha divisória decorativa
  stroke(255);
  strokeWeight(3);
  for (let i = 0; i < height; i += 20) {
    line(width/2, i, width/2, i + 10);
  }
  
  // Desenhar título
  fill(255);
  stroke(0);
  strokeWeight(2);
  textSize(28);
  text("🌾 Pontes de Sabor 🏙️", width/2, 30);
  
  // Desenhar rotas/conexões
  drawConnections();
  
  // Desenhar fazendas
  drawFarms();
  
  // Desenhar mercados
  drawMarkets();
  
  // Desenhar caminhões
  drawTrucks();
  
  // Interface do jogo
  drawGameUI();
  
  // Desenhar item sendo arrastado
  if (draggedItem) {
    stroke(colorRoute);
    strokeWeight(4);
    line(draggedItem.startX, draggedItem.startY, mouseX, mouseY);
    
    // Mostrar produto sendo arrastado
    drawProductIcon(mouseX + 10, mouseY - 10, draggedItem.product, 30);
  }
}

function drawGameUI() {
  // Painel de informações
  fill(0, 0, 0, 180);
  noStroke();
  rect(0, 0, width, 60);
  
  // Pontuação
  fill(255);
  textSize(18);
  text("💰 Pontos: " + score, 80, 30);
  
  // Nível
  text("📊 Nível: " + level, width/2, 30);
  
  // Temporizador
  fill(timer < 10 ? colorUI : 255);
  text("⏰ Tempo: " + Math.ceil(timer), width - 80, 30);
  
  // Progresso do festival
  let progressWidth = map(getCompletionPercentage(), 0, 100, 0, 300);
  fill(0, 0, 0, 100);
  rect(width/2 - 150, height - 30, 300, 20, 10);
  fill(colorRoute);
  rect(width/2 - 150, height - 30, progressWidth, 20, 10);
  fill(255);
  textSize(14);
  text("🎪 Festival: " + getCompletionPercentage() + "%", width/2, height - 20);
}

function drawFarms() {
  for (let i = 0; i < farms.length; i++) {
    let farm = farms[i];
    
    // Desenhar base da fazenda
    fill(farm.connected ? colorRoute : 255);
    stroke(0);
    strokeWeight(2);
    circle(farm.x, farm.y, farm.size + 10);
    
    // Desenhar ícone da fazenda
    drawFarmIcon(farm.x, farm.y - 10);
    
    // Desenhar produto
    drawProductIcon(farm.x, farm.y + 15, farm.product, 25);
  }
}

function drawMarkets() {
  for (let i = 0; i < markets.length; i++) {
    let market = markets[i];
    
    // Desenhar mercado como prédio
    drawMarketBuilding(market.x, market.y, market.connected);
    
    // Desenhar produto necessário
    fill(0);
    noStroke();
    textSize(12);
    text("Precisa:", market.x, market.y + 40);
    drawProductIcon(market.x, market.y + 55, market.needsProduct, 20);
  }
}

function drawConnections() {
  stroke(colorRoute);
  strokeWeight(4);
  
  for (let conn of activeConnections) {
    // Desenhar estrada
    line(conn.fromX, conn.fromY, conn.toX, conn.toY);
    
    // Desenhar linha pontilhada no meio
    stroke(255);
    strokeWeight(1);
    let steps = 20;
    for (let i = 0; i < steps; i++) {
      if (i % 2 === 0) {
        let x1 = lerp(conn.fromX, conn.toX, i / steps);
        let y1 = lerp(conn.fromY, conn.toY, i / steps);
        let x2 = lerp(conn.fromX, conn.toX, (i + 0.5) / steps);
        let y2 = lerp(conn.fromY, conn.toY, (i + 0.5) / steps);
        line(x1, y1, x2, y2);
      }
    }
  }
}

function drawTrucks() {
  for (let truck of trucks) {
    drawTruck(truck.x, truck.y, truck.angle);
    
    // Desenhar produto no caminhão
    drawProductIcon(truck.x, truck.y - 15, truck.product, 15);
  }
}

function drawTruck(x, y, angle) {
  push();
  translate(x, y);
  rotate(angle);
  
  // Corpo do caminhão
  fill(colorUI);
  stroke(0);
  strokeWeight(2);
  rect(-15, -8, 30, 16, 3);
  
  // Cabine
  fill(200);
  rect(-15, -8, 12, 16, 3);
  
  // Rodas
  fill(50);
  circle(-8, 8, 6);
  circle(8, 8, 6);
  circle(-8, -8, 6);
  circle(8, -8, 6);
  
  // Detalhes
  fill(255);
  rect(-12, -5, 6, 3);
  
  pop();
}

function drawFarmIcon(x, y) {
  push();
  translate(x, y);
  
  // Casa da fazenda
  fill(139, 69, 19);
  noStroke();
  rect(-10, -5, 20, 15);
  
  // Telhado
  fill(178, 34, 34);
  triangle(-12, -5, 0, -15, 12, -5);
  
  // Porta
  fill(101, 67, 33);
  rect(-3, 0, 6, 10);
  
  // Janela
  fill(135, 206, 235);
  rect(4, -2, 4, 4);
  
  pop();
}

function drawCityIcon(x, y) {
  push();
  translate(x, y);
  
  // Prédios
  fill(100);
  noStroke();
  rect(-15, -10, 8, 20);
  rect(-5, -15, 8, 25);
  rect(5, -8, 8, 18);
  
  // Janelas
  fill(255, 255, 0);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 2; j++) {
      rect(-13 + i * 3, -8 + j * 6, 2, 2);
      rect(-3 + i * 3, -13 + j * 6, 2, 2);
      rect(7 + i * 3, -6 + j * 6, 2, 2);
    }
  }
  
  pop();
}

function drawMarketBuilding(x, y, connected) {
  push();
  translate(x, y);
  
  // Prédio do mercado
  fill(connected ? colorRoute : colorCity);
  stroke(0);
  strokeWeight(2);
  rect(-25, -20, 50, 40, 5);
  
  // Telhado
  fill(connected ? 255 : 150);
  triangle(-25, -20, 0, -35, 25, -20);
  
  // Placa do mercado
  fill(255);
  rect(-20, -15, 40, 10);
  fill(0);
  noStroke();
  textSize(10);
  text("MERCADO", 0, -10);
  
  // Porta
  fill(101, 67, 33);
  stroke(0);
  strokeWeight(1);
  rect(-8, 5, 16, 15);
  
  // Janelas
  fill(135, 206, 235);
  rect(-18, -10, 8, 8);
  rect(10, -10, 8, 8);
  
  pop();
}

function drawProductIcon(x, y, product, size) {
  push();
  translate(x, y);
  
  switch (product) {
    case "milho":
      // Espiga de milho
      fill(255, 215, 0);
      noStroke();
      ellipse(0, 0, size, size * 1.5);
      fill(34, 139, 34);
      rect(-2, -size, 4, size/2);
      break;
      
    case "tomate":
      // Tomate
      fill(255, 99, 71);
      noStroke();
      circle(0, 0, size);
      fill(34, 139, 34);
      rect(-size/4, -size/2, size/2, size/4);
      break;
      
    case "leite":
      // Garrafa de leite
      fill(255);
      stroke(0);
      strokeWeight(1);
      rect(-size/3, -size/2, size*2/3, size);
      fill(0, 100, 255);
      noStroke();
      rect(-size/4, -size/2, size/2, size/4);
      break;
      
    case "ovos":
      // Ovos
      fill(255, 248, 220);
      noStroke();
      ellipse(-size/4, 0, size/2, size*2/3);
      ellipse(size/4, 0, size/2, size*2/3);
      break;
      
    case "alface":
      // Alface
      fill(124, 252, 0);
      noStroke();
      for (let i = 0; i < 6; i++) {
        let angle = i * PI / 3;
        let leafX = cos(angle) * size/3;
        let leafY = sin(angle) * size/3;
        ellipse(leafX, leafY, size/2, size/3);
      }
      break;
  }
  
  pop();
}

function drawButton(x, y, w, h, label, buttonColor) {
  let isHover = mouseX > x - w/2 && mouseX < x + w/2 && mouseY > y - h/2 && mouseY < y + h/2;
  
  // Sombra
  fill(0, 0, 0, 50);
  noStroke();
  rect(x - w/2 + 3, y - h/2 + 3, w, h, 10);
  
  // Botão
  fill(isHover ? brighten(buttonColor) : buttonColor);
  stroke(0);
  strokeWeight(2);
  rect(x - w/2, y - h/2, w, h, 10);
  
  // Texto
  fill(255);
  noStroke();
  textSize(20);
  text(label, x, y);
  
  return isHover;
}

function brighten(col) {
  let c = color(col);
  let r = red(c);
  let g = green(c);
  let b = blue(c);
  return color(min(r * 1.3, 255), min(g * 1.3, 255), min(b * 1.3, 255));
}

function drawGameOver() {
  background(colorUI);
  
  fill(255);
  stroke(0);
  strokeWeight(3);
  textSize(48);
  text("😢 Fim de Jogo", width/2, 180);
  
  textSize(24);
  noStroke();
  text("Pontuação: " + score, width/2, 250);
  text("Festivais Completados: " + festivalsCompleted, width/2, 290);
  
  drawButton(width/2, 380, 220, 60, "JOGAR NOVAMENTE", colorRoute);
}

function drawVictory() {
  background(colorField);
  
  fill(255);
  stroke(0);
  strokeWeight(3);
  textSize(48);
  text("🎉 Vitória! 🎉", width/2, 160);
  
  textSize(24);
  noStroke();
  text("Você conectou o campo e a cidade!", width/2, 220);
  text("Pontuação: " + score, width/2, 260);
  text("Festivais Completados: " + festivalsCompleted, width/2, 300);
  
  drawFireworks();
  
  drawButton(width/2, 420, 220, 60, "PRÓXIMO NÍVEL", colorRoute);
}

function drawFireworks() {
  for (let i = 0; i < 8; i++) {
    let x = random(width);
    let y = random(height/2);
    let colors = [colorRoute, colorField, colorCity, colorUI, "#FF00FF", "#00FFFF", "#FFFF00", "#FF8000"];
    let col = colors[i];
    
    fill(col);
    noStroke();
    
    for (let j = 0; j < 12; j++) {
      let angle = j * TWO_PI / 12;
      let length = random(15, 30);
      let endX = x + cos(angle) * length;
      let endY = y + sin(angle) * length;
      
      stroke(col);
      strokeWeight(3);
      line(x, y, endX, endY);
      
      noStroke();
      circle(endX, endY, random(5, 12));
    }
  }
}

function updateGame() {
  if (timer > 0) {
    timer -= 1/60;
  } else {
    gameState = "GAMEOVER";
  }
  
  // Atualizar caminhões
  updateTrucks();
  
  checkWinCondition();
}

function updateTrucks() {
  for (let i = trucks.length - 1; i >= 0; i--) {
    let truck = trucks[i];
    
    // Mover caminhão ao longo da rota (mais devagar)
    truck.progress += 0.008; // Velocidade do caminhão bem mais lenta
    
    if (truck.progress >= 1) {
      // Caminhão chegou ao destino
      trucks.splice(i, 1);
    } else {
      // Atualizar posição
      truck.x = lerp(truck.startX, truck.endX, truck.progress);
      truck.y = lerp(truck.startY, truck.endY, truck.progress);
      
      // Calcular ângulo do caminhão
      truck.angle = atan2(truck.endY - truck.startY, truck.endX - truck.startX);
    }
  }
}

function getCompletionPercentage() {
  if (markets.length === 0) return 0;
  
  let connected = markets.filter(market => market.connected).length;
  return Math.floor((connected / markets.length) * 100);
}

function checkWinCondition() {
  let allConnected = markets.every(market => market.connected);
  
  if (allConnected) {
    festivalsCompleted++;
    score += 1000 + (level * 500) + Math.floor(timer) * 10;
    gameState = "VICTORY";
  }
}

function mousePressed() {
  if (gameState === "MENU") {
    if (isButtonClicked(width/2, 320, 200, 60)) {
      gameState = "PLAYING";
    } else if (isButtonClicked(width/2, 400, 200, 60)) {
      gameState = "INSTRUCTIONS";
    }
  } else if (gameState === "INSTRUCTIONS") {
    if (isButtonClicked(width/2, 450, 200, 60)) {
      gameState = "MENU";
    }
  } else if (gameState === "PLAYING") {
    // Verificar clique em fazenda
    for (let farm of farms) {
      if (!farm.connected && dist(mouseX, mouseY, farm.x, farm.y) < farm.size/2) {
        draggedItem = {
          type: "farm",
          index: farms.indexOf(farm),
          product: farm.product,
          startX: farm.x,
          startY: farm.y
        };
        break;
      }
    }
  } else if (gameState === "GAMEOVER") {
    if (isButtonClicked(width/2, 380, 220, 60)) {
      resetGame();
    }
  } else if (gameState === "VICTORY") {
    if (isButtonClicked(width/2, 420, 220, 60)) {
      level++;
      setupLevel(level);
      gameState = "PLAYING";
    }
  }
}

function mouseReleased() {
  if (gameState === "PLAYING" && draggedItem) {
    // Verificar conexão com mercado
    for (let market of markets) {
      if (!market.connected && 
          dist(mouseX, mouseY, market.x, market.y) < market.size/2 &&
          draggedItem.product === market.needsProduct) {
        
        let farm = farms[draggedItem.index];
        farm.connected = true;
        market.connected = true;
        
        // Criar conexão
        activeConnections.push({
          fromX: farm.x,
          fromY: farm.y,
          toX: market.x,
          toY: market.y,
          product: draggedItem.product
        });
        
        // Criar caminhão
        trucks.push({
          x: farm.x,
          y: farm.y,
          startX: farm.x,
          startY: farm.y,
          endX: market.x,
          endY: market.y,
          progress: 0,
          angle: 0,
          product: draggedItem.product
        });
        
        score += 100 * level;
        break;
      }
    }
    
    draggedItem = null;
  }
}

function isButtonClicked(x, y, w, h) {
  return mouseX > x - w/2 && mouseX < x + w/2 && mouseY > y - h/2 && mouseY < y + h/2;
}

function resetGame() {
  score = 0;
  level = 1;
  festivalsCompleted = 0;
  trucks = [];
  setupLevel(level);
  gameState = "PLAYING";
}